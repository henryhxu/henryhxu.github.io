% reads espanix
clear all;
close all

folder = 'raw';
ixp = 'total-espanix-total-';
files = dir(folder);
% top left is origin
% Width: 500
% Height: 135
% length(files)
% linx is uint8
%% capture the demand curve
for ii = 3:length(files)
    nme = files(ii).name;
    if ~isempty(strfind(nme,ixp))
        nme = [folder '/' nme];
        info = imfinfo(nme);
        A = imread(nme);
        imshow(A);
        [m n] = size(A(:,:,1));
        IX = 1:m;
        up = 0;
        down = 0;
        green = 4;
        blue = 9;
        col_start = 82;
        col_end = 480;
        A0 = A(IX,:,:);
        com_start = 120;
        for i = col_start+1:col_end
            G = A0(:,i);
            G2 = G;
            % G2 is G shifted 1 pixle upwards
%             G2(1:length(G)-1) = G(2:length(G));
            % upmost green pixel: green in G, not green in G2 (1 pixel up)
            if ~isempty(find((G == green)))
                up(i-col_start) = min(find((G == green)));
            else
                up(i-col_start) = up(i-col_start-1);
            end;
            B = A0(:,i);
            B2 = B;
            B2(1:length(B)-1) = B(2:length(B));
            if ~isempty(find((B >= blue) & (B2 == blue)))
                down(i-col_start) = min(find((B >= blue) & (B2 == blue)));
            else
                down(i-col_start) = down(i-col_start-1);
            end;
        end;
        %% determine the numerical values manually
        % 200G at row 15
        % 0G at row 115
        % thus 2G/pixel
        base = 115; baseM = 0; alpha = 2;
        up = base-up;
        down = base-down;
        in = alpha*(up + baseM);
        out = alpha*(down + baseM);
        out_file = strcat(files(ii).name,'.mat');
        save(out_file,'in','out');
        y = prctile(in,95)
    end;
    
end;

y = prctile(in,95);

% ticks = [32:88:630-col_start];
% dates = {'Mon','Tue','Wed','Thu','Fri','Sat','Sun'};
plot(out);


% 
% set(gca,'XTick',ticks);
% set(gca,'XTickLabel',dates);
%
% for weekly graph, one column is 6 hrs, 22 pixels
% 1 pixel is thus 3/11 hr
% Mon is column-pixel 32+col_start=102
% fclose(fid);
