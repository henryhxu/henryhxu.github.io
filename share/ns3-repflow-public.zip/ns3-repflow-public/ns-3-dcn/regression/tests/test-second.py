#! /usr/bin/env python

"""Compare that Second generates correct traces."""

arguments = ["--verbose=0"]

