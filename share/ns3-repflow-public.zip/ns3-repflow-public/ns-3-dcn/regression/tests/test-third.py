#! /usr/bin/env python

"""Compare that Third generates correct traces."""

arguments = ["--verbose=0"]

