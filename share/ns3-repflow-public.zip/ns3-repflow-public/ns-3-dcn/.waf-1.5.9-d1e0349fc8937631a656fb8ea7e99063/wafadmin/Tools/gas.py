#! /usr/bin/env python
# encoding: utf-8

import os,sys
import Task
from TaskGen import extension,taskgen,after,before
EXT_ASM=['.s','.S','.asm','.ASM','.spp','.SPP']
as_str='${AS} ${ASFLAGS} ${_ASINCFLAGS} ${SRC} -o ${TGT}'
Task.simple_task_type('asm',as_str,'PINK',ext_out='.o',shell=False)
def asm_hook(self,node):
	task=self.create_task('asm')
	try:obj_ext=self.obj_ext
	except AttributeError:obj_ext='_%d.o'%self.idx
	task.inputs=[node]
	task.outputs=[node.change_ext(obj_ext)]
	self.compiled_tasks.append(task)
	self.meths.append('asm_incflags')
def asm_incflags(self):
	if self.env['ASINCFLAGS']:self.env['_ASINCFLAGS']=self.env['ASINCFLAGS']
	if'cxx'in self.features:self.env['_ASINCFLAGS']=self.env['_CXXINCFLAGS']
	else:self.env['_ASINCFLAGS']=self.env['_CCINCFLAGS']
def detect(conf):
	conf.find_program(['gas','as'],var='AS')
	if not conf.env.AS:conf.env.AS=conf.env.CC

extension(EXT_ASM)(asm_hook)
taskgen(asm_incflags)
after('apply_obj_vars_cc')(asm_incflags)
after('apply_obj_vars_cxx')(asm_incflags)
before('apply_link')(asm_incflags)
