// Construction of Fat-tree Architecture
// Author: Hong Xu <henryxu@eecg.toronto.edu>
// University of Toronto
// Heavily inspired by Linh Vu <linhvnl89@gmail.com>, Daji Wong <wong0204@e.ntu.edu.sg> 
// from Nanyang Technological University
// 

/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
* Copyright (c) 2013  
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License version 2 as
* published by the Free Software Foundation;
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
*/

#include <iostream>
#include <fstream>
#include <string>
#include <cassert>

#include "ns3/core-module.h"
#include "ns3/helper-module.h"
#include "ns3/node-module.h"
#include "ns3/simulator-module.h"
#include "ns3/log.h"
#include <time.h>
#include "ns3/internet-stack-helper.h"
#include "ns3/ipv4-address-helper.h"
#include "ns3/queue.h"
#include "ns3/cp-net-device.h"
#include "ns3/rp-net-device.h"
#include "ns3/uinteger.h"
#include "ns3/point-to-point-channel.h"
#include "ns3/ipv4-address-generator.h"
#include "ns3/ipv4-hash-routing-helper.h"
#include "ns3/random-variable.h"
#include "ns3/packet-sink.h"
#include "ns3/fat-tree-helper.h"

/*

- The code is constructed in the following order:
1. Creation of Node Containers 
2. Initialize settings for On/Off Application
3. Connect hosts to edge switches
4. Connect edge switches to aggregate switches
5. Connect aggregate switches to core switches
6. Start Simulation

- Addressing scheme:
1. Address of host: 10.pod.switch.0 /24
2. Address of edge and aggregation switch: 10.pod.switch.0 /16
3. Address of core switch: 10.(group number + k).switch.0 /8
(Note: there are k/2 group of core switch)

- On/Off Traffic of the simulation: addresses of client and server are randomly selected everytime
	
- Simulation Settings:
- Number of pods (k): 4-72 (run the simulation with varying values of k)
- Number of nodes: 16-3400
- Simulation running time: 0.1 seconds
- Packet size: 1024 bytes
- Data rate for packet sending: 1000 Mbps
- Data rate for device channel: 1000 Mbps
- Delay time for device: 0.001 ms
- Communication pairs selection: Random Selection with uniform probability

- Statistics Output:
- Flowmonitor XML output file: Fat-tree.xml is located in the /statistics folder
            

*/

using namespace ns3;
using namespace std;
NS_LOG_COMPONENT_DEFINE ("Fat-Tree-Architecture");


// Main function
//
int 
	main(int argc, char *argv[])
{
	//=========== Define parameters for topology ===========//
	int k = 6;					// Number of pods 
		
	//int total_flows = 50; 	// Number of flows
	double linkDelay = 5e-9;	// Link delay in seconds (5ns = 1m wire)
	double linkBw = 1e9;		// Link bandwidth in bps	
	int rr=1;
	bool replicate = false;			// Replicated flows
	double interarrival = 0.00028;	// Interarrival mean time
	int dup = 1;					// How many duplicates for each flow
	int cdftype = 1;				// Flow size ditribution to choose: 1 for DCTCP, 2 for VL2
	double tSim = 0.01;				// Simulation time
	int run = 1;					// Number of simulation run

	//=========== Define variables for On/Off Application  ===========//
	uint32_t nsender;
	uint32_t nreceiver;
	int port = 1000;
	int packetSize = 1460;
	//int maxBytes = 300000;		// start with 30KB

	// Initialize other variables
	int i = 0;	

	//=========== Configure applications and transport protocols  ===========//
	Config::SetDefault ("ns3::QbbNetDevice::QbbEnabled", BooleanValue(false));		
	// This dramatically helps reduce the memory footprint
	Config::SetDefault ("ns3::QbbNetDevice::BufferSize", UintegerValue(75536));	// 64KiB
	Config::SetDefault ("ns3::HashRouting::IntelReroute", BooleanValue(rr == 2));
	Config::SetDefault ("ns3::HashRouting::CnLifetime", TimeValue(Seconds(0.01)));
	
	// Important TCP tuning and queue sizes
	Config::SetDefault ("ns3::TcpSocket::SegmentSize", UintegerValue(1460));
	Config::SetDefault("ns3::TcpSocket::DelAckCount", UintegerValue (0));
	Config::SetDefault("ns3::TcpSocket::DelAckTimeout", TimeValue(Seconds (0)));
	// This helps to reduce the initial delay for TCP flows
	//Config::SetDefault ("ns3::TcpL4Protocol::SocketFactory", StringValue("ns3::TcpNewReno"));
	Config::SetDefault ("ns3::TcpSocket::SlowStartThreshold", UintegerValue(65535*2));
	//Config::SetDefault ("ns3::TcpSocket::SndBufSize", UintegerValue(131072));
	//Config::SetDefault ("ns3::TcpSocket::RcvBufSize", UintegerValue(131072));
	//Config::SetDefault ("ns3::DropTailQueue::Mode", StringValue("QUEUE_MODE_PACKETS"));
	//Config::SetDefault ("ns3::DropTailQueue::MaxPackets", UintegerValue(225));
	

	// Get inputs from command line
    CommandLine cmd;
    //cmd.AddValue ("shortFlows", "Number of total short flows", total_flows);
    //cmd.AddValue ("longFlows", "Number of total long flows", long_flows);
    cmd.AddValue ("cdftype", "Which traffic distribution", cdftype);
	cmd.AddValue ("replicate", "Whether to use flow replication", replicate);
	cmd.AddValue ("arrival", "Arrival rate of short flows", interarrival);
	cmd.AddValue ("tSim", "Simulation time", tSim);
	cmd.AddValue ("run", "Which run to use", run);
	cmd.AddValue ("k", "Number of pods", k);	// For lage-scale, use k=16, hosts = 1024
	cmd.Parse (argc, argv);
	
	int n = k/2;					// Fat tree size
	int total_host = k*k*k/4;	// Number of hosts in the entire network
	
	// Create the Fat-tree topology
	Ptr<FatTreeHelper> net = CreateObject<FatTreeHelper>(n);
	net->SetAttribute("HeDelay", TimeValue(Seconds(linkDelay)));
	net->SetAttribute("EaDelay", TimeValue(Seconds(linkDelay)));
	net->SetAttribute("AcDelay", TimeValue(Seconds(linkDelay)));
	net->SetAttribute("HeDataRate", DataRateValue(DataRate(linkBw)));
	net->SetAttribute("EaDataRate", DataRateValue(DataRate(linkBw)));
	net->SetAttribute("AcDataRate", DataRateValue(DataRate(linkBw)));
	net->Create();
	NodeContainer hosts = net->HostNodes();
	
	char *filename = (char *)malloc(60*sizeof(char));
	if (cdftype == 1)
		sprintf(filename, "statistics/DCTCP/Run%d-%.2f-%f-%d-%d.xml", run, tSim, interarrival, k, replicate);
	else if (cdftype == 2)
		sprintf(filename, "statistics/VL2/Run%d-%.2f-%f-%d-%d.xml", run, tSim, interarrival, k, replicate);
	else {
		std::cout << "Wrong traffic distribution type selected!\n";
		return 0;
	}
	
	// Generate traffics for the simulation
	ApplicationContainer flows;
	ApplicationContainer sinkApps;
	// Different runs use different run number for RNG
	SeedManager::SetSeed ( (run));
	ExponentialVariable x(interarrival);
	double tflow = 0;
	EmpiricalVariable fsize;
	if (cdftype == 1) {		// DCTCP traffic trace
		fsize.CDF (6.0, 0.15);
		fsize.CDF (13.0, 0.2);
		fsize.CDF (19.0, 0.3);
		fsize.CDF (33.0, 0.4);
		fsize.CDF (53.0, 0.53);
		fsize.CDF (133.0, 0.6);
		fsize.CDF (667.0, 0.7);
		fsize.CDF (1333.0, 0.8);
		fsize.CDF (3333.0, 0.9);
		fsize.CDF (6667.0, 0.97);
		fsize.CDF (20000.0, 1.0);
	}
	else if (cdftype == 2) {	// VL2 traffic trace
		fsize.CDF (1.0, 0.5);
		fsize.CDF (2.0, 0.6);
		fsize.CDF (3.0, 0.7);
		fsize.CDF (7.0, 0.8);
		fsize.CDF (267.0, 0.9);
		fsize.CDF (2107.0, 0.95);
		fsize.CDF (66667.0, 0.999);
		fsize.CDF (666667.0, 1.0);
	}

	for (i=0;tflow <= tSim ;i++,port++){
		// Generate a flow starting time
		tflow += x.GetValue();
		// Randomly select a receiver
		nreceiver = rand() % total_host;
		Ptr<Node> receiver = hosts.Get(nreceiver);
		Ptr<NetDevice> ren = receiver->GetDevice(0);
		Ptr<Ipv4> ipv4 = receiver->GetObject<Ipv4> ();
		NS_ASSERT_MSG (ipv4, "NetDevice is associated"
                		" with a node without IPv4 stack installed -> fail "
						"(maybe need to use InternetStackHelper?)");
		Ipv4InterfaceAddress r_ip = ipv4->GetAddress (1,0);
		Ipv4Address r_ipaddr = r_ip.GetLocal();

		// Initialize On/Off Application with addresss of receiver
	    OnOffHelper source ("ns3::TcpSocketFactory", Address (InetSocketAddress(r_ipaddr, port)));
	    source.SetAttribute ("OnTime", RandomVariableValue (ConstantVariable (1)));
	    source.SetAttribute ("OffTime", RandomVariableValue (ConstantVariable (0)));
		source.SetAttribute ("DataRate", StringValue ("1Gbps"));
		
	    // Set the amount of data to send in bytes.  Zero is unlimited.
		int tempsize = fsize.GetInteger();
		
		//std::cout << "flow size is " << tempsize << std::endl;
	    source.SetAttribute ("MaxBytes", UintegerValue (tempsize*1000));
		source.SetAttribute("PacketSize",UintegerValue (packetSize));
		
		// Randomly select a sender
		nsender = rand() % total_host;

		while (nsender == nreceiver){
			nsender = rand() % total_host;
		} // to make sure that client and server are different
		
		// Install sink	
		PacketSinkHelper sink("ns3::TcpSocketFactory", Address(InetSocketAddress(Ipv4Address::GetAny(), port)));
		sinkApps.Add(sink.Install(hosts.Get(nreceiver)));
		
		// Install source to the sender
		NodeContainer onoff;
		onoff.Add(hosts.Get(nsender));
		flows.Add(source.Install (onoff));
		// Get the current flow
		Ptr<Application> the_flow = flows.Get(flows.GetN()-1);
		the_flow->SetStartTime(Seconds(tflow));
		
		// Initialize the duplicated flow with addresss of server
		if (replicate) {
			for (int m=0; m<dup; m++) {
				// Increment the port number to avoid performance penalty
				port++;
				if (tempsize <= 55) {
					OnOffHelper source1 ("ns3::TcpSocketFactory",Address(InetSocketAddress(r_ipaddr, port)));
				    source1.SetAttribute ("OnTime", RandomVariableValue (ConstantVariable (1)));
				    source1.SetAttribute ("OffTime", RandomVariableValue (ConstantVariable (0)));
					source1.SetAttribute ("DataRate", StringValue ("1Gbps"));
					source1.SetAttribute("PacketSize",UintegerValue (packetSize));
					source1.SetAttribute("DataRate",StringValue ("1Gbps"));
					source1.SetAttribute("MaxBytes",UintegerValue (tempsize*1000));
					flows.Add(source1.Install (hosts.Get(nsender)));
					// Get the current flow
					the_flow = flows.Get(flows.GetN()-1);
					the_flow->SetStartTime(Seconds(tflow));
					PacketSinkHelper sink1("ns3::TcpSocketFactory", Address(InetSocketAddress(Ipv4Address::GetAny(), port)));
					sinkApps.Add(sink1.Install(hosts.Get(nreceiver)));
					// Get traces for debugging
					//Ptr<Node> ssender = hosts.Get(nsender);
					//Ptr<NetDevice> ss_dev = ssender->GetDevice(0);
					//PointToPointHelper::EnablePcap ("host", ss_dev);
				}
			}
		}
	}
	
	flows.Stop(Seconds(tSim+1));
	sinkApps.Start(Seconds(0));
	sinkApps.Stop(Seconds(tSim+1));
	std::cout << "Finished creating "<< i-1 << " flows for " << tSim << " seconds...\n";
	
	//=========== Start the simulation ===========//
	std::cout << "Start Simulation.. "<<"\n";

	// Calculate Throughput using Flowmonitor
	FlowMonitorHelper flowmon;
	Ptr<FlowMonitor> monitor = flowmon.InstallAll();
	//PointToPointHelper::EnablePcap ("ss", hosts);
	
	
	// Run simulation.
	NS_LOG_INFO ("Run Simulation.");
	Simulator::Stop (Seconds(tSim+1));
	Simulator::Run ();

	cout << "Run finished, now writing output...\n";
	monitor->CheckForLostPackets ();
	monitor->SerializeToXmlFile(filename, false, false);

	std::cout << "Simulation finished "<<"\n";

	Simulator::Destroy ();
	NS_LOG_INFO ("Done.");
	
	//for (i=0; i<total_flows; i++) { 
 //   	Ptr<PacketSink> sink1 = DynamicCast<PacketSink> (sinkApps.Get (i));
   // 	std::cout << "Throughput: " << sink1->GetTotalRx ()*8/0.1/1000000000 << std::endl;
	//}

	return 0;
}




