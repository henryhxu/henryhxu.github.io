
void RunSimulation (void);

int main (int argc, char *argv[])
{
  RunSimulation ();

  return 0;
}
